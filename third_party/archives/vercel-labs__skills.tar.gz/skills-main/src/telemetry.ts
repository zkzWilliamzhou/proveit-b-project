import { isCI } from './ci.ts';

const TELEMETRY_URL = 'https://www.skills.sh/tele/t';
const AUDIT_URL = 'https://www.skills.sh/tele/audit';

interface InstallTelemetryData {
  event: 'install';
  source: string;
  skills: string;
  agents: string;
  global?: '1';
  skillFiles?: string; // JSON stringified { skillName: relativePath }
  /** User-facing URL that can be passed back to `skills add`. */
  installUrl?: string;
  /** Caller-provided JSON attached to this install telemetry event. */
  metadata?: string;
  /**
   * Source type for different hosts:
   * - 'github': GitHub repository (default, uses raw.githubusercontent.com)
   * - 'raw': Direct URL to SKILL.md (generic raw URL)
   * - Provider IDs like 'mintlify', 'huggingface', etc.
   */
  sourceType?: string;
}

interface RemoveTelemetryData {
  event: 'remove';
  source?: string;
  skills: string;
  agents: string;
  global?: '1';
  sourceType?: string;
}

interface UpdateTelemetryData {
  event: 'update';
  scope?: string;
  skillCount: string;
  successCount: string;
  failCount: string;
}

interface FindTelemetryData {
  event: 'find';
  query: string;
  resultCount: string;
  interactive?: '1';
}

interface SyncTelemetryData {
  event: 'experimental_sync';
  skillCount: string;
  successCount: string;
  agents: string;
}

type TelemetryData =
  | InstallTelemetryData
  | RemoveTelemetryData
  | UpdateTelemetryData
  | FindTelemetryData
  | SyncTelemetryData;

let cliVersion: string | null = null;
let detectedAgentName: string | null = null;

/**
 * Set the detected AI agent name for telemetry tracking.
 * Called once during agent detection, then included in all telemetry events.
 */
export function setDetectedAgent(agentName: string | null): void {
  detectedAgentName = agentName;
}

function isEnabled(): boolean {
  return !process.env.DISABLE_TELEMETRY && !process.env.DO_NOT_TRACK;
}

export function setVersion(version: string): void {
  cliVersion = version;
}

// ─── Security audit data ───

export interface PartnerAudit {
  risk: 'safe' | 'low' | 'medium' | 'high' | 'critical' | 'unknown';
  alerts?: number;
  score?: number;
  analyzedAt: string;
}

export type SkillAuditData = Record<string, PartnerAudit>;
export type AuditResponse = Record<string, SkillAuditData>;

/**
 * Fetch security audit results for skills from the audit API.
 * Returns null on any error or timeout — never blocks installation.
 */
export async function fetchAuditData(
  source: string,
  skillSlugs: string[],
  timeoutMs = 3000
): Promise<AuditResponse | null> {
  if (!isEnabled()) return null;
  if (skillSlugs.length === 0) return null;

  try {
    const params = new URLSearchParams({
      source,
      skills: skillSlugs.join(','),
    });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    const response = await fetch(`${AUDIT_URL}?${params.toString()}`, {
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!response.ok) return null;
    return (await response.json()) as AuditResponse;
  } catch {
    return null;
  }
}

// Pending telemetry requests — awaited before CLI exit so we don't lose data,
// but never block the main workflow.
const pendingTelemetry: { promise: Promise<void>; controller: AbortController }[] = [];

export function track(data: TelemetryData): void {
  if (!isEnabled()) return;

  try {
    const params = new URLSearchParams();

    // Add version
    if (cliVersion) {
      params.set('v', cliVersion);
    }

    // Add CI flag if running in CI
    if (isCI()) {
      params.set('ci', '1');
    }

    // Add detected AI agent name
    if (detectedAgentName) {
      params.set('agent', detectedAgentName);
    }

    // Add event data
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined && value !== null) {
        params.set(key, String(value));
      }
    }

    // Fire and forget during the workflow, but track the promise and controller so
    // flushTelemetry() can await it before the process exits and abort hanging sockets.
    const controller = new AbortController();
    const p = fetch(`${TELEMETRY_URL}?${params.toString()}`, {
      signal: controller.signal,
    })
      .catch(() => {})
      .then(() => {});
    pendingTelemetry.push({ promise: p, controller });
  } catch {
    // Silently fail - telemetry should never break the CLI
  }
}

/**
 * Wait for all in-flight telemetry requests to settle.
 * Called once at CLI exit so the process doesn't hang on open sockets
 * but also doesn't drop data by exiting too early.
 */
export async function flushTelemetry(timeoutMs = 5000): Promise<void> {
  const pending = pendingTelemetry.splice(0);
  if (pending.length === 0) return;
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<void>((resolve) => {
    timer = setTimeout(resolve, timeoutMs);
  });
  await Promise.race([Promise.all(pending.map((item) => item.promise)), timeout]);
  // The CLI exits by draining the event loop, so neither the timer nor a hung
  // request may outlive the flush.
  clearTimeout(timer);
  for (const item of pending) item.controller.abort();
}
